export const settings = {
    server: 'http://localhost:3000/graphql'
}