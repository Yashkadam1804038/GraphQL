const Task = (props) => {
    const { id, title, description } = props

    
    return <div className="card"  style={{  display: 'inline-block', margin: '10px', height: '150px'}}>
         <div className="card-body">
    <h5 className="card-title">{title}</h5>
    <p className="card-text">{description}</p>
    {/* <button className="btn btn-success">Done</button> */}
     </div>
    </div>
}

export default Task