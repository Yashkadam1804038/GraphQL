import axios from "axios"
import { settings } from "../config"
import { print } from 'graphql'
import { gql } from '@apollo/client'


export const getTask = async(status = '') => {

 
    const token = sessionStorage['token']
    const response = await axios({
        method: 'POST',
        url: settings.server,
        headers:{
            Authorization: `Bearer ${token}`
        },
        data: {
            query:  print(gql`
            query tasks($status: String!){
                tasks(status: $status){
                    id
                    title
                    description
                    status
                }
            }
            
           ` ),
            
           variables: {
               status,
           },
        },
    })
    return response.data
}
    

export const createTask = async(title, description, status='') => {

    const url = settings.server + `/task?status=${status}`
    const token = sessionStorage['token']
    let response
    try{
     response = await axios.post(url,{
         title,
         description
     }, {
         headers: {
             Authorization: `Bearer ${token}`
         }
     })

     response = response.data
    } catch(ex){
        console.log(ex)
    }

    return response
}

export const createTaskStatus = async(id, status) => {

    const url = settings.server + `/task/${id}/${status}`
    const token = sessionStorage['token']
    let response
    try{
     response = await axios.patch(url,{
        
     }, {
         headers: {
             Authorization: `Bearer ${token}`
         }
     })

     response = response.data
    } catch(ex){
        console.log(ex)
    }

    return response
}