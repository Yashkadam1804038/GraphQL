
import { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import Task from "../components/task.component"
import { getTask } from "../services/task.service"

const TaskListPage = (props) => {

    // state
    const [tasks, setTasks] = useState([])   // used to check current state and updated states
    const navigate = useNavigate()

    // this function is called as soon as the page loads
    useEffect(() => {
        reloadTasks()
    }, [])

    // load tasks by calling the get api
    const reloadTasks = async() => {
        const result = await getTask()
        console.log(result)
        if(result.errors && result.errors.length > 0){
          const error = result.errors[0].message
          alert(error)
        } else{
            if(result.data) {
               setTasks(result.data.tasks)
            }
        }
    }

    // logout
    const logout = () => {
        // remove the token and username from sessionStorage
        sessionStorage.removeItem('token')
        sessionStorage.removeItem('username')

        // redirect to signin
        navigate('/signin')
    }
    return( <div>
        <button onClick={logout} style= {{ float: 'right'}}className="btn btn-warning">Logout</button>
        <h1 className="header">Task List</h1>

        <Link to="/task-create">Create new task</Link>
        <div className="row">
            <div className="col"><h2>
                Open</h2>
                {tasks.map((task) => {
            const {id, title, description} = task
            return <Task id={id} title={title} description={description}></Task>
        })}
        </div>
                
                
                </div>
                </div>
        
    
    )
}

export default TaskListPage