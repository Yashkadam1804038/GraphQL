const ProfilePage = (props) => {
return ( <div>
        <h1 className="header">User Profile</h1>
    </div>
)
}

export default ProfilePage