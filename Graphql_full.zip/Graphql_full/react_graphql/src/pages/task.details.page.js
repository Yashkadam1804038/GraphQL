const TaskDetailsPage = (props) => {
    return (<div>
        <h1 className="header">Task Details</h1>
    </div>
    )
}

export default TaskDetailsPage