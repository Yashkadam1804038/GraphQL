# REST to GraphQL transition

- install the dependency

>yarn add @nestjs/graphql @nestjs/apollo graphql apollo-server-express

- remove the controllers
-add types
-add resolvers

# users

- remove usercontrollers
- add User Type
