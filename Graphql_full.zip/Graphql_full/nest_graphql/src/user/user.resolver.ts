
import {Query, Args, Mutation, Resolver } from "@nestjs/graphql";
import { UserService } from "./user.service";
import { UserType } from "./types/user.type";
import { UserInput } from "./types/user.input";
import { SigninResponse } from "./types/signin.response";
import { UseGuards } from "@nestjs/common";
import { GQLAuthGuard } from "./gql.authguard";
import { GetUser } from "./get.user.decorator";
import { UserEntity } from "./user.entity";

// whenever request comes to UserType the resolver will recieve it and work on it
@Resolver((of) => UserType)
export class UserResolver{
  
    // dependency injection
    constructor(private userService: UserService) {

    }
    // mutation returns newly created user in UserType
    @Mutation((returns) => UserType)
    signup(
        @Args('input') input: UserInput,        // args used for accepting username & passwords as field
      
        ) {
            return this.userService.signup(input);
        }
 

  @Query((returns) => UserType)
  // here we are using authguard which is going to call api
  // this api will check if user is passing the auth token or not
  @UseGuards(GQLAuthGuard)
   profile(@GetUser() user: UserEntity) {
       return user;
   }

    @Mutation(returns => SigninResponse)
   signin(@Args('input') input: UserInput) {
       return this.userService.signin(input)
   }
}