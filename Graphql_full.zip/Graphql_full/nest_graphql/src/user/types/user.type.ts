import { Field, ID, ObjectType } from "@nestjs/graphql";

// newly created request comes to UserType

@ObjectType('User')
export class UserType{
    
    @Field((type) => ID)
    id: number;

    @Field()
    username: string;
}