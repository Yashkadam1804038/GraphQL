
export class AuthCredentialsDTO{
    
    
    username: string

    password: string
    
}


