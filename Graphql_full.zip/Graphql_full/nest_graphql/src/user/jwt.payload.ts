
export interface Jwtpayload {

    username: string;
    id: number;
}