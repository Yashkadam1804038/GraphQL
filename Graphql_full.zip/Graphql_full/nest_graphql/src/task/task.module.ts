import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserModule } from 'src/user/user.module';

import { TaskRepository } from './task.repository';
import { TaskResolver } from './task.resolver';
import { TaskService } from './task.service';
import { TaskInputType } from './types/task.input';
import { TaskType } from './types/task.type';

@Module({

  // use typeorm to create the table task using repository
  imports: [TypeOrmModule.forFeature([TaskRepository]), UserModule],
  controllers: [],
  providers: [TaskService, TaskResolver]
  
})
export class TaskModule {}
