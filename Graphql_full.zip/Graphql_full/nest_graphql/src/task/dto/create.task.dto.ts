// this is data transfer object
// which  is used to transfer data from one to other entity
export class CreateTaskDTO{
   title: string;
   description: string;
}