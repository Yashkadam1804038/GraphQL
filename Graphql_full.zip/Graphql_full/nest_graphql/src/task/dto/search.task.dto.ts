// this is data transfer object

import { TaskStatus } from "../task.enum";

// which  is used to transfer data from one to other entity
export class SearchTaskDTO{
    search: string;
    status: TaskStatus;
 }