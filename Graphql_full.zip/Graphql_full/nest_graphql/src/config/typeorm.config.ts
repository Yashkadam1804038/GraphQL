// configuration for db connection

import { TypeOrmModuleOptions } from "@nestjs/typeorm";


export const TypeORMConfiguration: TypeOrmModuleOptions = {
    username: 'root',
    password: 'rootpassword',
    port: 3306,
    host: 'localhost',
    type: 'mysql',
    database: 'TaskManagerV2',
    entities: [__dirname + '/../**/*.entity.{ts,js}'],

 synchronize: false,

};